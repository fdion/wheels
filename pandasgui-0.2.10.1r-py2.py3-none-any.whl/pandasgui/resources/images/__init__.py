"""All image files used in this project"""
